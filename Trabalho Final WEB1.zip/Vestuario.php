<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<title>Vestuario</title>
	<link rel="stylesheet" type="text/css" href="Forma.css">
</head>
	<body>
		<fieldset>
		<?php
			echo '<a href="Loja Virtual.php">Index</a> -
				  <a href="Informatica.php">Informatica</a> -
				  <a href="Vestuario.php">Vestuario</a> -
				  <a href="Moveis.php">Móveis</a> -
				  <a href="Tela de Login.php">Sair</a>';
		?>
		</fieldset>
		<fieldset>
		<?php
			echo '<a href="#tenis">TÊNIS</a> -
				 <a href="#chuteira">CHUETEIRA</a> -
				 <a href="#calça">CALÇA</a> -
				 <a href="#camisa">CAMISA</a>'
		?>
		</fieldset>
		<fieldset>
			<legend><a name="tenis">TÊNIS</a></legend>
				<?php
					include'Produtos.php';
					for ($i=34; $i <= 51; $i++) { 
						if ($i==34) {
							echo "CASUAL<br>";
							echo "----------------------------------------------------------------------------------------------------------------------------------------------------";
							echo "<br>";
						}
						$im = strval($i);
						$image="Imagens\img" . $im . ".jpg";
						print"<img src=\"$image\" width=\"300\" height=\"300\"\/>";
						echo "<br>";echo "<br>";echo "<br>";
						echo "PRODUTO: ";
						print_r($produtos[$i]["descricao"]);
						echo "<br>";
						echo " COR: ";
						print_r($produtos[$i]["cor"]);
						echo "<br>";
						echo " MARCA: ";
						print_r($produtos[$i]["marca"]);
						echo "<br>";
						echo " PREÇO: ";
						print_r($produtos[$i]["preco"]);
						echo "<br>";
						if ($i==38) {
							echo "<br>";
							echo "BASQUETE<br>";
							echo "----------------------------------------------------------------------------------------------------------------------------------------------------";
							echo "<br>";
						}
						if ($i==41) {
							echo "<br>";
							echo "SKATE<br>";
							echo "----------------------------------------------------------------------------------------------------------------------------------------------------";
							echo "<br>";
						}
						if ($i==44) {
							echo "<br>";
							echo "CORRIDA<br>";
							echo "----------------------------------------------------------------------------------------------------------------------------------------------------";
							echo "<br>";
						}
					}
				?>
		</fieldset>
		<fieldset>
			<legend><a name="chuteira">CHUETEIRA</a></legend>
				<?php
					include'Produtos.php';
					for ($i=52; $i <= 57; $i++) { 
						if ($i==52) {
							echo "SOCIETY<br>";
							echo "----------------------------------------------------------------------------------------------------------------------------------------------------";
							echo "<br>";
						}
						$im = strval($i);
						$image="Imagens\img" . $im . ".jpg";
						print"<img src=\"$image\" width=\"300\" height=\"300\"\/>";
						echo "<br>";echo "<br>";echo "<br>";
						echo "PRODUTO: ";
						print_r($produtos[$i]["descricao"]);
						echo "<br>";
						echo " COR: ";
						print_r($produtos[$i]["cor"]);
						echo "<br>";
						echo " MARCA: ";
						print_r($produtos[$i]["marca"]);
						echo "<br>";
						echo " PREÇO: ";
						print_r($produtos[$i]["preco"]);
						echo "<br>";
						if ($i==54) {
							echo "<br>";
							echo "CAMPO<br>";
							echo "----------------------------------------------------------------------------------------------------------------------------------------------------";
							echo "<br>";
						}
					}
				?>
		</fieldset>
		<fieldset>
			<legend><a name="calça">CALÇA</a></legend>
				<?php
					include'Produtos.php';
					for ($i=58; $i <= 63; $i++) { 
						if ($i==58) {
							echo "JEANS<br>";
							echo "----------------------------------------------------------------------------------------------------------------------------------------------------";
							echo "<br>";
						}
						$im = strval($i);
						$image="Imagens\img" . $im . ".jpg";
						print"<img src=\"$image\" width=\"300\" height=\"300\"\/>";
						echo "<br>";echo "<br>";echo "<br>";
						echo "PRODUTO: ";
						print_r($produtos[$i]["descricao"]);
						echo "<br>";
						echo " COR: ";
						print_r($produtos[$i]["cor"]);
						echo "<br>";
						echo " MARCA: ";
						print_r($produtos[$i]["marca"]);
						echo "<br>";
						echo " PREÇO: ";
						print_r($produtos[$i]["preco"]);
						echo "<br>";
					}
				?>
		</fieldset>
		<fieldset>
			<legend><a name ="camisa">CAMISA</a></legend>
				<?php
					include'Produtos.php';
					for ($i=64; $i <= 79; $i++) { 
						if ($i==64) {
							echo "POLO<br>";
							echo "----------------------------------------------------------------------------------------------------------------------------------------------------";
							echo "<br>";
						}
						$im = strval($i);
						$image="Imagens\img" . $im . ".jpg";
						print"<img src=\"$image\" width=\"300\" height=\"300\"\/>";
						echo "<br>";echo "<br>";echo "<br>";
						echo "PRODUTO: ";
						print_r($produtos[$i]["descricao"]);
						echo "<br>";
						echo " COR: ";
						print_r($produtos[$i]["cor"]);
						echo "<br>";
						echo " MARCA: ";
						print_r($produtos[$i]["marca"]);
						echo "<br>";
						echo " PREÇO: ";
						print_r($produtos[$i]["preco"]);
						echo "<br>";
						if ($i==71) {
							echo "<br>";
							echo "REGATA<br>";
							echo "----------------------------------------------------------------------------------------------------------------------------------------------------";
							echo "<br>";
						}
						if ($i==75) {
							echo "<br>";
							echo "CAMISETA<br>";
							echo "----------------------------------------------------------------------------------------------------------------------------------------------------";
							echo "<br>";
						}
					}
				?>
		</fieldset>
		<fieldset>
		<?php
			echo '<a href="#tenis">VOLTAR PRO INÍCIO</a>'
		?>
		</fieldset>
		<fieldset>
		<?php
			include'Rodape.php';
		?>
		</fieldset>
	</body>
</html>