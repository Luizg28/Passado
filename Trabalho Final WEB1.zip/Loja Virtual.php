<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<title>Loja Virtual</title>
	<link rel="stylesheet" type="text/css" href="Forma.css">
</head>
	<body>
		<fieldset>
		<?php
			if($_POST['login'] == 'Luiz' and $_POST['senha'] == 123){
					echo '<a href="Informatica.php">Informatica</a> -
				  		  <a href="Vestuario.php">Vestuario</a> -
				  		  <a href="Moveis.php">Móveis</a> -
				  		  <a href="Tela de Login.php">Sair</a>';
					echo "<p>Loja Virtual</p>";
					echo "<a>Bem Vindo a Loja Virtual, aqui você encontra os mais variados produtos de diversas áreas.</a><br>";
					print"<img src=\"Imagens\inf.jpg\" width=\"400\" height=\"400\"\/>";
					print"<img src=\"Imagens\mov.jpg\" width=\"400\" height=\"400\"\/>";
					print"<img src=\"Imagens\Beste.jpg\" width=\"400\" height=\"400\"\/>";
					echo "<br><br><br>";
					include'Rodape.php'; 
				}
			else{
				echo "Digite Novamente o login ou senha";
				include'Tela de Login.php';
			}
		?>
		</fieldset>
	</body>
</html>