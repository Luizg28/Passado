<html>

	<head>
		<meta charset="utf-8"/>
		<title>Login</title>
		<link rel="stylesheet" type="text/css" href="Forma.css">
	</head>

	
	<body>
		<fieldset>
		<p>Login</p>
		</fieldset>
		<table>
			<form action="Loja Virtual.php" method="post">
				<fieldset>

					<label> Login:</label>
					<input type="text" name="login"/>
					</br></br>
					
					
					<label>Senha: </label>
					<input type="password" name="senha"/>
					</br></br>


				</fieldset>

				<input type="submit" name="enviar" value="Confirmar" id="conf"/>
			</form>
		</table>
	</body>
	<?php 
	echo "<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>";
	include'Rodape.php'; 
	?>
</html>