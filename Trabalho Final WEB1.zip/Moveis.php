<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<title>Móveis</title>
	<link rel="stylesheet" type="text/css" href="Forma.css">
</head>
	<body>
		<fieldset>
		<?php
			echo '<a href="Loja Virtual.php">Index</a> -
				  <a href="Informatica.php">Informatica</a> -
				  <a href="Vestuario.php">Vestuario</a> -
				  <a href="Moveis.php">Móveis</a> -
				  <a href="Tela de Login.php">Sair</a>';
		?>
		</form>
		</fieldset>
		<fieldset>
		<?php
			echo '<a href="#sofa">SOFÁ</a> -
				 <a href="#cama">CAMA</a>'
		?>
		</fieldset>
		<fieldset>
			<legend><a name="sofa">SOFÁ</a></legend>
				<?php
					include'Produtos.php';
					for ($i=80; $i <= 89; $i++) { 
						if ($i==80) {
							echo "2 LUGARES<br>";
							echo "----------------------------------------------------------------------------------------------------------------------------------------------------";
							echo "<br>";
						}
						$im = strval($i);
						$image="Imagens\img" . $im . ".jpg";
						print"<img src=\"$image\" width=\"300\" height=\"300\"\/>";
						echo "<br>";echo "<br>";echo "<br>";
						echo "PRODUTO: ";
						print_r($produtos[$i]["descricao"]);
						echo "<br>";
						echo " COR: ";
						print_r($produtos[$i]["cor"]);
						echo "<br>";
						echo " MARCA: ";
						print_r($produtos[$i]["marca"]);
						echo "<br>";
						echo " PREÇO: ";
						print_r($produtos[$i]["preco"]);
						echo "<br>";
						if ($i==85) {
							echo "<br>";
							echo "3 LUGARES<br>";
							echo "----------------------------------------------------------------------------------------------------------------------------------------------------";
							echo "<br>";
						}
					}
				?>
		</fieldset>
		<fieldset>
			<legend><a name="cama">CAMA</a></legend>
				<?php
					include'Produtos.php';
					for ($i=90; $i <= 101; $i++) { 
						if ($i==90) {
							echo "CASAL<br>";
							echo "----------------------------------------------------------------------------------------------------------------------------------------------------";
							echo "<br>";
						}
						$im = strval($i);
						$image="Imagens\img" . $im . ".jpg";
						print"<img src=\"$image\" width=\"300\" height=\"300\"\/>";
						echo "<br>";echo "<br>";echo "<br>";
						echo "PRODUTO: ";
						print_r($produtos[$i]["descricao"]);
						echo "<br>";
						echo " COR: ";
						print_r($produtos[$i]["cor"]);
						echo "<br>";
						echo " MARCA: ";
						print_r($produtos[$i]["marca"]);
						echo "<br>";
						echo " PREÇO: ";
						print_r($produtos[$i]["preco"]);
						echo "<br>";
						if ($i==93) {
							echo "<br>";
							echo "SOLTEIRO<br>";
							echo "----------------------------------------------------------------------------------------------------------------------------------------------------";
							echo "<br>";
						}
						if ($i==97) {
							echo "<br>";
							echo "BELICHE<br>";
							echo "----------------------------------------------------------------------------------------------------------------------------------------------------";
							echo "<br>";
						}
					}
				?>
		</fieldset>
		<fieldset>
		<?php
			echo '<a href="#sofa">VOLTAR PRO INÍCIO</a>'
		?>
		</fieldset>
		<fieldset>
		<?php
			include'Rodape.php';
		?>
		</fieldset>
	</body>
</html>