<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<title>Informatica</title>
	<link rel="stylesheet" type="text/css" href="Forma.css">
</head>
	<body>
		<fieldset>
		<?php
			echo '<a href="Loja Virtual.php">Index</a> -
				  <a href="Informatica.php">Informatica</a> -
				  <a href="Vestuario.php">Vestuario</a> -
				  <a href="Moveis.php">Móveis</a> -
				  <a href="Tela de Login.php">Sair</a>';
		?>
		</fieldset>
		<fieldset>
		<?php
			echo '<a href="#laptop">LAPTOPS</a> -
				 <a href="#acessorio">ACESSÓRIO</a>'
		?>
		</fieldset>
		<fieldset>
			<legend><a name="laptop">LAPTOPS</a></legend>
				<?php
					include'Produtos.php';

						for ($i=0; $i <= 22; $i++) {
						if ($i==0) {
							echo "NOTEBOOK<br>";
							echo "----------------------------------------------------------------------------------------------------------------------------------------------------";
							echo "<br>";
						} 
						$im = strval($i);
						$image="Imagens\img" . $im . ".jpg";
						print"<img src=\"$image\" width=\"300\" height=\"300\"\/>";
						echo "<br>";echo "<br>";echo "<br>";
						echo "PRODUTO: ";
						print_r($produtos[$i]["descricao"]);
						echo "<br>";
						echo " COR: ";
						print_r($produtos[$i]["cor"]);
						echo "<br>";
						echo " MARCA: ";
						print_r($produtos[$i]["marca"]);
						echo "<br>";
						echo " PREÇO: ";
						print_r($produtos[$i]["preco"]);
						echo "<br>";
						if ($i==11) {
							echo "<br>";
							echo "GAMERS<br>";
							echo "----------------------------------------------------------------------------------------------------------------------------------------------------";
							echo "<br>";
						}
						if ($i==17) {
							echo "<br>";
							echo "2 EM 1<br>";
							echo "----------------------------------------------------------------------------------------------------------------------------------------------------";
							echo "<br>";
						}
					}
				?>
		</fieldset>
		<fieldset>
			<legend><a name="acessorio">ACESSÓRIO</a></legend>
				<?php
					include'Produtos.php';

						for ($i=23; $i <= 33; $i++) { 
						if ($i==23) {
							echo "HD EXTERNO<br>";
							echo "----------------------------------------------------------------------------------------------------------------------------------------------------";
							echo "<br>";
						}
						$im = strval($i);
						$image="Imagens\img" . $im . ".jpg";
						print"<img src=\"$image\" width=\"300\" height=\"300\"\/>";
						echo "<br>";echo "<br>";echo "<br>";
						echo "PRODUTO: ";
						print_r($produtos[$i]["descricao"]);
						echo "<br>";
						echo " COR: ";
						print_r($produtos[$i]["cor"]);
						echo "<br>";
						echo " MARCA: ";
						print_r($produtos[$i]["marca"]);
						echo "<br>";
						echo " PREÇO: ";
						print_r($produtos[$i]["preco"]);
						echo "<br>";
						echo "<br>";
						if ($i==27) {
							echo "<br>";
							echo "MOUSE<br>";
							echo "----------------------------------------------------------------------------------------------------------------------------------------------------";
							echo "<br>";
						}
						if ($i==30) {
							echo "<br>";
							echo "TECLADO<br>";
							echo "----------------------------------------------------------------------------------------------------------------------------------------------------";
							echo "<br>";
						}
					}
				?>
		</fieldset>
		<fieldset>
		<?php
			echo '<a href="#laptop">VOLTAR PRO INÍCIO</a>'
		?>
		</fieldset>
		<fieldset>
		<?php
			include'Rodape.php';
		?>
		</fieldset>
	</body>
</html>